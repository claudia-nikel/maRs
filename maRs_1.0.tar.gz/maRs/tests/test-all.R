library("testthat")
test_check("maRs")