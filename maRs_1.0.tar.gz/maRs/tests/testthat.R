library(testthat)
library(maRs)

test_check("maRs")
